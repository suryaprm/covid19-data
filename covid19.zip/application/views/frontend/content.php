<?php
$this->load->view('frontend/templates/header');
$this->load->view($content);
$this->load->view('frontend/templates/footer');
 ?>
