
$.getJSON('https://api.kawalcorona.com/indonesia/provinsi', function(data){
    console.log(data);
});